# UP Police Study App v2

1000 practice questions across 6 subjects:
- सामान्य ज्ञान: 180
- सामान्य हिंदी: 160
- संविधान / कानून: 160
- संख्यात्मक योग्यता: 200
- मानसिक अभिरुचि: 150
- तार्किक क्षमता: 150

The question bank contains practice/generated variants and is not presented as official UPPRPB previous-year questions. Check current official recruitment notices and syllabus before relying on exam-specific details.
